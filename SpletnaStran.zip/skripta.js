
const obrazec = document.querySelector("#main-form");

if (obrazec instanceof HTMLFormElement) {
    obrazec.addEventListener("submit", (dogodek) => {
        dogodek.preventDefault();   //prepreči osvežitev strani

        const podatki = new FormData(obrazec);
        const polja = {
            ime: document.querySelector("#izpis-ime"),
            email: document.querySelector("#izpis-email"),
            tema: document.querySelector("#izpis-tema"),
            sporocilo: document.querySelector("#izpis-sporocilo")
        };

        for (const [imePolja, izpis] of Object.entries(polja)) {  //z zanko kroži po "polja", preveri za napako in izpiše
            if (!(izpis instanceof HTMLElement)) {
                throw new Error(`Manjka element za izpis polja "${imePolja}".`);
            }

            izpis.textContent = String(podatki.get(imePolja) ?? "");
        }

       const rezultat = document.querySelector("#oddano-sporocilo");  //kilče da se v podstran 1 pojavi izpis oddanega sporočila
        if (!(rezultat instanceof HTMLElement)) {
            throw new Error("Napaka");
        }

        rezultat.hidden = false;

        
    });
}

const kviz = document.querySelector("#kviz-zvezde");

if (kviz instanceof HTMLFormElement) {
    kviz.addEventListener("submit", (dogodek) => {
        dogodek.preventDefault();

        const podatki = new FormData(kviz);
        const pravilniOdgovori = {
            vprasanje1: "sonce",
            vprasanje2: "temperatura",
            vprasanje3: "supernova",
            vprasanje4: "orion",
            vprasanje5: "sirius"
        };
        let steviloPravilnih = 0;

        for (const [vprasanje, pravilenOdgovor] of Object.entries(pravilniOdgovori)) {
            if (podatki.get(vprasanje) === pravilenOdgovor) {
                steviloPravilnih++;
            }
        }

        const rezultat = document.querySelector("#rezultat-kviza");
        if (!(rezultat instanceof HTMLElement)) {
            throw new Error("Npaka");
        }

        rezultat.textContent = `Pravilnih odgovorov: ${steviloPravilnih} od 5.`;
        const vsaPravilna = steviloPravilnih === Object.keys(pravilniOdgovori).length;
        rezultat.classList.toggle("kviz-uspeh", vsaPravilna);
        rezultat.classList.toggle("kviz-neuspeh", !vsaPravilna);
    });
}



 